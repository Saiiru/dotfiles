-- Definir a tecla líder como espaço
vim.g.mapleader = " "

local keymap = vim.keymap -- para concisão

---------------------
-- Mapeamentos Básicos -------------------

-- Remaps básicos
keymap.set("v", "J", ":m '>+1<CR>gv=gv", { desc = "Mover linha selecionada para baixo" })
keymap.set("v", "K", ":m '<-2<CR>gv=gv", { desc = "Mover linha selecionada para cima" })

-- Sair do modo de inserção com 'jk'
keymap.set("i", "jk", "<ESC>", { desc = "Sair do modo de inserção" })

-- Scrolling Remaps
keymap.set("n", "<C-d>", "<C-d>zz", { desc = "Descer uma tela e centralizar" })
keymap.set("n", "<C-u>", "<C-u>zz", { desc = "Subir uma tela e centralizar" })
keymap.set("n", "n", "nzzzv", { desc = "Procurar próximo e centralizar" })
keymap.set("n", "N", "Nzzzv", { desc = "Procurar anterior e centralizar" })

-- Copilot Remaps
vim.g.copilot_no_tab_map = true
vim.api.nvim_set_keymap("i", "<C-J>", 'copilot#Accept("<CR>")', { silent = true, expr = true })

-- Mapeamentos de janelas
keymap.set("n", "<S-h>", "<C-w>h", { desc = "Mover para a janela à esquerda" })
keymap.set("n", "<S-l>", "<C-w>l", { desc = "Mover para a janela à direita" })
keymap.set("n", "<leader>j", "<C-w>j", { desc = "Mover para a janela abaixo" })
keymap.set("n", "<leader>k", "<C-w>k", { desc = "Mover para a janela acima" })

-- Gerenciamento de janelas
keymap.set("n", "<leader>sv", "<C-w>v", { desc = "Dividir janela verticalmente" }) -- dividir janela verticalmente
keymap.set("n", "<leader>sh", "<C-w>s", { desc = "Dividir janela horizontalmente" }) -- dividir janela horizontalmente
keymap.set("n", "<leader>se", "<C-w>=", { desc = "Tornar janelas de tamanhos iguais" }) -- tornar janelas de tamanhos iguais
keymap.set("n", "<leader>sx", "<cmd>close<CR>", { desc = "Fechar janela atual" }) -- fechar janela atual

-- Redimensionamento de janelas
keymap.set("n", "<leader>.", ":vertical resize +15<CR>", { desc = "Aumentar largura da janela" })
keymap.set("n", "<leader>,", ":vertical resize -15<CR>", { desc = "Diminuir largura da janela" })
keymap.set("n", "<leader>=", "<C-w>=", { desc = "Fazer janelas iguais" })

-- Clipboard Remaps
keymap.set({ "n", "v" }, "<leader>y", [["+y]], { desc = "Copiar para o clipboard" })
keymap.set("n", "<leader>Y", [["+Y]], { desc = "Copiar linha atual para o clipboard" })
keymap.set({"n", "v"}, "<leader>dd", [["_d]], { desc = "Deletar sem copiar" })

-- Remaps de busca
keymap.set("n", "<leader><space>", function()
	vim.cmd("nohlsearch") -- limpar destaque de busca
end, { desc = "Limpar destaques de busca" })

-- Desativar setas
-- keymap.set({ "n", "v", "i" }, "<Up>", "<Nop>", { desc = "Desativar tecla para cima" })
-- keymap.set({ "n", "v", "i" }, "<Down>", "<Nop>", { desc = "Desativar tecla para baixo" })
-- keymap.set({ "n", "v", "i" }, "<Left>", "<Nop>", { desc = "Desativar tecla para esquerda" })
-- keymap.set({ "n", "v", "i" }, "<Right>", "<Nop>", { desc = "Desativar tecla para direita" })
--
-- Remaps de Undo/Redo
keymap.set("n", "U", "<C-r>", { desc = "Refazer ação" })

-- Mapear a abertura do gerenciador de arquivos
keymap.set("n", "<leader>pv", vim.cmd.Ex, { desc = "Abrir gerenciador de arquivos" })

-- Formatação de buffer
keymap.set("n", "<leader>lf", vim.lsp.buf.format, { desc = "Formatar o código com LSP" })

-- Navegação entre erros
keymap.set("n", "<C-k>", "<cmd>cnext<CR>zz", { desc = "Navegar para o próximo erro" })
keymap.set("n", "<C-j>", "<cmd>cprev<CR>zz", { desc = "Navegar para o erro anterior" })
keymap.set("n", "<leader>k", "<cmd>lnext<CR>zz", { desc = "Navegar para o próximo aviso" })
keymap.set("n", "<leader>j", "<cmd>lprev<CR>zz", { desc = "Navegar para o aviso anterior" })

-- Incrementar e decrementar números
keymap.set("n", "<leader>+", "<C-a>", { desc = "Incrementar número" }) -- incrementar
keymap.set("n", "<leader>-", "<C-x>", { desc = "Decrementar número" }) -- decrementar

-- Executar comandos do terminal
keymap.set("n", "<leader>xs", "<cmd>!chmod +x %<CR>", { silent = true, desc = "Adicionar permissão de execução" })

-- Adicionar o erro padrão no Go
keymap.set("n", "<leader>eer", "oif err != nil {<CR>}<Esc>Oreturn err<Esc>", { desc = "Adicionar verificação de erro no Go" })

-- Abre o arquivo de configuração do Packer
keymap.set("n", "<leader>vpp", "<cmd>e ~/.dotfiles/nvim/.config/nvim/lua/theprimeagen/packer.lua<CR>", { desc = "Abrir arquivo de configuração do Packer" })

-- Executar a CellularAutomaton
keymap.set("n", "<leader>mr", "<cmd>CellularAutomaton make_it_rain<CR>", { desc = "Executar CellularAutomaton" })

-- Reiniciar o LSP
keymap.set("n", "<leader>zig", "<cmd>LspRestart<cr>", { desc = "Reiniciar LSP" })

-- Mapear "Vim with Me"
keymap.set("n", "<leader>vwm", function()
	require("vim-with-me").StartVimWithMe()
end, { desc = "Iniciar sessão Vim com Me" })
keymap.set("n", "<leader>svwm", function()
	require("vim-with-me").StopVimWithMe()
end, { desc = "Parar sessão Vim com Me" })

-- Mapear para salvar configurações
keymap.set("n", "<leader><leader>", function()
	vim.cmd("so") -- Source para recarregar a configuração
end, { desc = "Recarregar configuração" })

