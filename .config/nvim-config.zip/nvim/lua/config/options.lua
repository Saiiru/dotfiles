-- Define o líder da tecla (para mapeamentos)
vim.g.mapleader = " "
vim.g.maplocalleader = "\\"

-- Opções de exibição de números de linha
vim.opt.number = true             -- exibe número absoluto na linha do cursor
vim.opt.relativenumber = true     -- exibe números relativos

-- Configurações de tabs e indentação
vim.opt.tabstop = 2               -- define 2 espaços para tabs
vim.opt.shiftwidth = 2            -- define 2 espaços para a largura de indentação
vim.opt.softtabstop = 2           -- define 2 espaços para a tecla de tabulação
vim.opt.expandtab = true          -- expande tabulações para espaços
vim.opt.smartindent = true        -- ativa a indentação inteligente

-- Configurações de quebra de linha
vim.opt.wrap = false              -- desativa a quebra de linha

-- Opções de pesquisa
vim.opt.ignorecase = true         -- ignora maiúsculas e minúsculas na pesquisa
vim.opt.smartcase = true          -- ativa a pesquisa sensível a maiúsculas se houver maiúsculas

-- Opções de linha do cursor
vim.opt.cursorline = true         -- destaca a linha atual do cursor

-- Configurações de aparência
vim.opt.termguicolors = true      -- ativa cores verdadeiras no terminal
vim.opt.background = "dark"       -- define o fundo como escuro
vim.opt.signcolumn = "yes"        -- exibe a coluna de sinais para evitar deslocamento de texto

-- Configurações de backspace
vim.opt.backspace = "indent,eol,start" -- permite usar backspace em indentação, fim de linha ou início do modo de inserção

-- Configurações de área de transferência
vim.opt.clipboard:append("unnamedplus") -- usa a área de transferência do sistema como registro padrão

-- Configurações de janelas divididas
vim.opt.splitright = true         -- abre janelas verticais à direita
vim.opt.splitbelow = true         -- abre janelas horizontais abaixo

-- Configurações de swapfile
vim.opt.swapfile = false          -- desativa o arquivo de swap

-- Configurações de rolagem
vim.opt.scrolloff = 8             -- mantém 8 linhas visíveis acima e abaixo do cursor

-- Configurações de largura do número
vim.opt.numberwidth = 1           -- define a largura da coluna de número para 1

-- Configurações de folding
vim.opt.foldmethod = "indent"     -- define o método de dobra como indentação
vim.opt.foldexpr = "nvim_treesitter#foldexpr()" -- usa o Treesitter para determinar a dobra
vim.opt.foldlevelstart = 99       -- inicia com todas as dobras abertas

-- Configurações de preenchimento de caracteres
vim.opt.fillchars:append({
    eob = " ",                     -- remove o caractere de fim de buffer
    horiz = " ",                   -- caractere horizontal
    horizup = " ",                 -- caractere horizontal para cima
    horizdown = " ",               -- caractere horizontal para baixo
    vert = " ",                    -- caractere vertical
    vertleft = " ",                -- caractere vertical à esquerda
    vertright = " ",               -- caractere vertical à direita
    verthoriz = " ",               -- caractere vertical horizontal
})

-- Configurações de pesquisa de destaque
vim.opt.hlsearch = false          -- desativa o destaque de pesquisa
vim.opt.incsearch = true          -- ativa a pesquisa incremental

