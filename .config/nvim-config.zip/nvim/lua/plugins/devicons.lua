return {
	"nvim-tree/nvim-web-devicons",
	opts = {
		color_icons = false,
		default = true,
		strict = true,
	},
}
