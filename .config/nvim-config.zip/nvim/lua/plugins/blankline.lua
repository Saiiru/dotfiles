return {
  "lukas-reineke/indent-blankline.nvim",
  version = "2.20.8",
  event = { "BufReadPre", "BufNewFile" },
  config = function()
    -- Enable list mode to visualize whitespace
    vim.cmd("set list")
    -- Uncomment to use dots for spaces
    -- vim.cmd("set lcs+=space:.") 

    -- Highlight styles for indent lines
    vim.cmd([[
      highlight IndentBlanklineChar guifg=#1c1c1c
      highlight IndentBlanklineSpaceChar guifg=#1c1c1c
      highlight IndentBlanklineSpaceCharBlankline guifg=#1c1c1c
      highlight IndentBlanklineContextChar guifg=#333333
    ]])

    -- Indent lines settings
    require("indent_blankline").setup({
      char = "┊",                       -- Character used for indentation
      show_current_context = true,      -- Show current context
      show_current_context_start = false,-- Do not highlight the start of the current context
      space_char_blankline = " ",       -- Use a space for blank lines
      indent_blankline_use_treesitter = true, -- Integrate with Treesitter for better performance
    })
  end,
}


