return {

	"williamboman/mason.nvim",
	dependencies = {
		"williamboman/mason-lspconfig.nvim",
		"WhoIsSethDaniel/mason-tool-installer.nvim",
	},
	config = function()
		local mason_ok, mason = pcall(require, "mason")
		if not mason_ok then
			return
		end

		local mason_lspconfig_ok, mason_lspconfig = pcall(require, "mason-lspconfig")
		if not mason_lspconfig_ok then
			return
		end

		local mason_tool_installer_ok, mason_tool_installer = pcall(require, "mason-tool-installer")
		if not mason_tool_installer_ok then
			return
		end

		require("plugins.lsp.server.java")

		mason.setup({
			ui = {
				icons = {
					package_installed = "✓",
					package_pending = "➜",
					package_uninstalled = "✗",
				},
			},
		})

		mason_lspconfig.setup({
			ensure_installed = {
				"ts_ls", -- TypeScript
				"html", -- HTML
				"cssls", -- CSS
				"tailwindcss", -- Tailwind CSS
				"lua_ls", -- Lua
				"phpactor", -- PHP (Laravel)
				"jsonls", -- JSON
				"graphql", -- GraphQL
				"emmet_ls", -- Emmet
				"prismals", -- Prisma
				"pyright", -- Python
				"gopls", -- Go
				"dockerls", -- Docker
				"jdtls", -- Java
				"angularls", -- Angular
			},
		})

		mason_tool_installer.setup({
			ensure_installed = {
				"prettier", -- Prettier formatter
				"stylua", -- Lua formatter
				"isort", -- Python formatter
				"black", -- Python formatter
				"pylint", -- Python linter
				"eslint_d", -- JS linter
				"google-java-format", -- Java formatter
				"checkstyle", -- Java linter
			},
		})

		-- -- Auto format on save
		-- vim.api.nvim_create_autocmd("BufWritePre", {
		-- 	pattern = { "*.js", "*.ts", "*.lua", "*.py" },
		-- 	callback = function()
		-- 		vim.lsp.buf.formatting_sync()
		-- 	end,
		-- })
	end,
}
