return {
  "nvim-lua/plenary.nvim", -- lua functions that many plugins use
  "christoomey/vim-tmux-navigator", -- tmux & split window navigation
  -- Git plugins
	{ "tpope/vim-fugitive" },
	{ "sindrets/diffview.nvim" },
	-- LSP plugins
	{ "L3MON4D3/LuaSnip", version = "2.*", build = "make install_jsregexp" },
	-- Utils
	{ "tpope/vim-commentary" },
	{ "norcalli/nvim-colorizer.lua", event = "BufEnter", opts = { "*" } },
	{ "mg979/vim-visual-multi" },
	  {
        'github/copilot.vim',
        config = function()
            -- Desabilitar mapeamento padrão do Tab
            vim.g.copilot_no_tab_map = true
            vim.g.copilot_assume_mapped = true           
            -- Mapeamento para aceitar sugestões do Copilot
            -- Altere <C-j> para outro atalho, por exemplo <C-Enter>
            vim.api.nvim_set_keymap("i", "<C-Enter>", 'copilot#Accept("<CR>")', { expr = true, silent = true })
        end
    },
  -- neotest
  { "nvim-neotest/nvim-nio" },
  -- Cellular automation
  {"eandrju/cellular-automaton.nvim"},
  -- wakatime
  {"wakatime/vim-wakatime"},
  -- nvim-jdtls (java)
  {"mfussenegger/nvim-jdtls"},
}
