return {
	"stevearc/conform.nvim",
	event = { "BufReadPre", "BufNewFile" },
	config = function()
		local conform = require("conform")

		conform.setup({
			formatters_by_ft = {
				javascript = { "prettier" }, -- Prettier para JavaScript
				typescript = { "prettier" }, -- Prettier para TypeScript
				javascriptreact = { "prettier" }, -- Prettier para React (JSX)
				typescriptreact = { "prettier" }, -- Prettier para React (TSX)
				svelte = { "prettier" }, -- Prettier para Svelte
				css = { "prettier" }, -- Prettier para CSS
				html = { "prettier" }, -- Prettier para HTML
				json = { "prettier" }, -- Prettier para JSON
				yaml = { "prettier" }, -- Prettier para YAML
				markdown = { "prettier" }, -- Prettier para Markdown
				graphql = { "prettier" }, -- Prettier para GraphQL
				liquid = { "prettier" }, -- Prettier para Liquid (HTML templates)
				lua = { "stylua" }, -- Stylua para Lua
				python = { "isort", "black" }, -- isort e black para Python
				go = { "gofmt" }, -- Gofmt para Go
				java = { "google_java_format" }, -- Google Java Format para Java
				dockerfile = { "dockfmt" }, -- Dockerfile formatter
				sh = { "shfmt" }, -- Shell Script formatter
			},
			format_on_save = {
				lsp_fallback = true,
				async = false,
				timeout_ms = 1000,
			},
		})

		-- Keybinding para formatar arquivos ou blocos de código selecionados no modo visual
		vim.keymap.set({ "n", "v" }, "<leader>mp", function()
			conform.format({
				lsp_fallback = true,
				async = false,
				timeout_ms = 1000,
			})
		end, { desc = "Format file or range (in visual mode)" })
	end,
}
