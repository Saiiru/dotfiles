return {
  "tpope/vim-surround",
   event = { "BufReadPre", "BufNewFile" },
  version = "*",
  config = function()
    -- Configuração de keybindings para surround
    -- Adiciona surround
    vim.api.nvim_set_keymap('n', '<Leader>sy', 'ys', { noremap = true, silent = true, desc = "Adicionar surround" })
    -- Troca surround
    vim.api.nvim_set_keymap('n', '<Leader>ss', 'cs', { noremap = true, silent = true, desc = "Trocar surround" })
    -- Remove surround
    vim.api.nvim_set_keymap('n', '<Leader>sr', 'ds', { noremap = true, silent = true, desc = "Remover surround" })
    
    -- Exemplos de comandos surround
    vim.api.nvim_command([[
      " Adiciona surround a uma palavra
      " Exemplo: `ysiw{}` vai envolver a palavra atual em {}
      
      " Troca surround
      " Exemplo: `cs() {}` troca () por {}
      
      " Remove surround
      " Exemplo: `ds{}` remove as chaves em torno da palavra
    ]])
  end
}
