return {
    "jesseleite/nvim-noirbuddy",
    dependencies = {
        "tjdevries/colorbuddy.nvim",
    },
    priority = 1000,
    config = function()
        require("noirbuddy").setup({
            preset = "minimal",
            styles = {
                italic = true,
                bold = true,
                underline = true,
                undercurl = true,
                variable = { bold = true, italic = true },
                function_ = { bold = true, italic = false },
            },
            colors = {
                background = "#1c1c2d",  -- Dark blue background
                primary = "#00ffff",      -- Bright cyan for primary text
                secondary = "#bd93f9",    -- Purple for secondary elements
                noir_0 = "#8be9fd",       -- Light blue for less important text
                noir_1 = "#ffffff",       -- Brighter text color
                noir_2 = "#7aa2ff",       -- Soft bright blue for better visibility
                noir_3 = "#44475a",       -- Darker gray for general elements
                noir_4 = "#282a36",       -- Base dark color
                noir_5 = "#f8f8f2",       -- Very light gray for subtle highlights
                noir_6 = "#ff5555",       -- Red for errors or important elements
                noir_7 = "#ffb86c",       -- Light orange for attention
                noir_8 = "#50fa7b",       -- Green for success
                noir_9 = "#bd93f9",       -- Purple for keywords and functions
            },
        })

        -- Tokens colors
        vim.cmd("highlight @variable guifg=#00ffff gui=bold,italic")  -- Custom style
        vim.cmd("highlight @variable.builtin guifg=#ffffff gui=bold")  -- More visible color
        vim.cmd("highlight @variable.member guifg=#8be9fd gui=italic")

        vim.cmd("highlight @constant guifg=#f8f8f2 gui=bold")

        vim.cmd("highlight @keyword guifg=#bd93f9 gui=bold")  -- Custom vibrant color
        vim.cmd("highlight @keyword.operator guifg=#8be9fd gui=bold")
        vim.cmd("highlight @keyword.function guifg=#00ffff gui=bold,italic")
        vim.cmd("highlight @keyword.return guifg=#00ffff gui=bold")

        vim.cmd("highlight @punctuation.bracket guifg=#ffffff gui=bold")

        vim.cmd("highlight @constructor guifg=#bd93f9 gui=bold")

        vim.cmd("highlight @operator guifg=#00ffff gui=bold")
        vim.cmd("highlight @comment guifg=#7aa2ff gui=italic")  -- More visible comments
        vim.cmd("highlight @string guifg=#50fa7b gui=italic")  -- Bright strings

        vim.cmd("highlight @keyword.coroutine guifg=#00ffff gui=bold")

        vim.cmd("highlight @function.builtin guifg=#ffffff gui=bold")
        vim.cmd("highlight @function.call guifg=#ffffff gui=bold")
        vim.cmd("highlight @function.method.call guifg=#ffffff gui=bold")

        vim.cmd("highlight @tag guifg=#00ffff gui=bold")
        vim.cmd("highlight @tag.delimiter guifg=#bd93f9 gui=bold")
        vim.cmd("highlight @tag.attribute guifg=#ffffff gui=bold")

        vim.cmd("highlight @lsp.type.parameter guifg=#ffffff gui=italic")

        vim.cmd("highlight @type guifg=#8be9fd gui=bold")
        vim.cmd("highlight @type.qualifier guifg=#bd93f9 gui=bold")

        -- Vim command line error colors
        vim.cmd("highlight ErrorMsg guifg=#ff5555 guibg=#ff8989")  -- Bright red for errors

        -- NvimTree colors
        vim.cmd("highlight NvimTreeFolderIcon guifg=#8be9fd")
        vim.cmd("highlight NvimTreeFolderName guifg=#8be9fd gui=bold")
        vim.cmd("highlight NvimTreeFileIcon guifg=#bd93f9")
        vim.cmd("highlight NvimTreeFileName guifg=#bd93f9")
        vim.cmd("highlight NvimTreeIndentMarker guifg=#6272a4")
        vim.cmd("highlight NvimTreeNormal guibg=NONE guifg=#ffffff")
        vim.cmd("highlight NvimTreeVertSplit guibg=NONE guifg=NONE")

        vim.cmd("highlight NvimTreeCursorLine guibg=#282a36 guifg=NONE gui=bold")

        -- Diagnostic colors
        vim.cmd("highlight DiagnosticError guifg=#ff5555")
        vim.cmd("highlight DiagnosticWarn guifg=#ffb86c")
        vim.cmd("highlight DiagnosticInfo guifg=#50fa7b")
        vim.cmd("highlight DiagnosticHint guifg=#bd93f9")

        -- Diagnostic signs colors
        vim.cmd("highlight DiagnosticSignError guifg=#ff5555")
        vim.cmd("highlight DiagnosticSignWarn guifg=#ffb86c")
        vim.cmd("highlight DiagnosticSignInfo guifg=#50fa7b")
        vim.cmd("highlight DiagnosticSignHint guifg=#bd93f9")

        -- Editor transparent colors
        vim.cmd("highlight Normal guibg=none")
        vim.cmd("highlight NonText guibg=none")
        vim.cmd("highlight Normal ctermbg=none")
        vim.cmd("highlight NonText ctermbg=none")

        -- LSP colors
        vim.cmd("highlight FloatBorder guibg=NONE guifg=#ffffff")
        vim.cmd("highlight FloatShadow guibg=NONE guifg=NONE")
        vim.cmd("highlight FloatShadowThrough guibg=NONE guifg=NONE")

        -- Visual mode colors
        vim.cmd("highlight Visual guibg=#282a36 guifg=NONE")

        -- Numbers Gutter
        vim.cmd("highlight LineNr guifg=#ffffff")

        vim.cmd("highlight Cursor guibg=NONE")
        vim.cmd("highlight CursorLine guibg=#282a36 guifg=NONE")
        vim.cmd("highlight CursorLineNr guibg=NONE guifg=#ffffff gui=bold")

        -- Split colors
        vim.cmd("highlight VertSplit guibg=NONE guifg=#1c1c2d")
        vim.cmd("highlight WinSeparator guibg=NONE guifg=#1c1c2d")

        -- Command line colors
        vim.cmd("highlight Pmenu guibg=#181818 guifg=#ffffff")
        vim.cmd("highlight PmenuSel guibg=#bd93f9 guifg=#ffffff")
        vim.cmd("highlight PmenuSbar guibg=#181818 guifg=#0f0f0f")
        vim.cmd("highlight PmenuThumb guibg=#222222 guifg=#0f0f0f")

        -- Floating window colors
        vim.cmd("highlight NormalFloat guibg=NONE guifg=#ffffff")

        -- Fold colors
        vim.cmd("highlight Folded guibg=NONE guifg=#ffffff")

        -- Gitsigns colors
        vim.cmd("highlight GitSignsAdd guifg=#50fa7b")
        vim.cmd("highlight GitSignsChange guifg=#bd93f9")
        vim.cmd("highlight GitSignsDelete guifg=#ff5555")

        -- Telescope colors
        vim.cmd("highlight TelescopeBorder guibg=NONE guifg=#ffffff")

        -- Noice colors
        vim.cmd("highlight NoiceCmdlineIcon guibg=NONE guifg=#ffffff")
        vim.cmd("highlight NoiceCmdlinePopup guibg=NONE guifg=#ffffff")
        vim.cmd("highlight NoiceCmdlinePopupBorderInput guibg=NONE guifg=#444444")
        vim.cmd("highlight NoiceCmdlinePopupBorder guibg=NONE guifg=#222222")

        -- Devicons colors
        vim.cmd("highlight DevIconDefault guifg=#ffffff")
    end,
}

