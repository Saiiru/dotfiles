return {
    "nvim-treesitter/nvim-treesitter",
    build = ":TSUpdate",
    lazy = vim.fn.argc(-1) == 0, -- carregar o Treesitter ao abrir arquivos pela linha de comando
    dependencies = {
        "nvim-treesitter/playground",
        "windwp/nvim-ts-autotag",
    },
    opts = {
        sync_install = false,
        auto_install = true,
        ensure_installed = {
            "lua",
            "javascript",
            "typescript",
            "java",
            "go",
            "dockerfile",
            "json",
            "yaml",
            "html",
            "css",
            "markdown",
            "markdown_inline",
            "bash",
            "rust",
            "prisma",
            "tsx",
            "svelte",
            "graphql",
            "gitignore",
            "query",
            "vimdoc",
            "c",
        },
        indent = {
            enable = true,
            disable = "yaml",
        },
        highlight = {
            enable = true,
            additional_vim_regex_highlighting = { "markdown" },
        },
    },
    config = function(_, opts)
        -- Configuração padrão do nvim-treesitter
        require("nvim-treesitter.configs").setup(opts)

        -- Verificação para garantir que o parser esteja disponível
        local ts_parsers = require("nvim-treesitter.parsers")

        -- Função para verificar se o parser está disponível
        local function safe_get_parser(lang)
            local parser = ts_parsers.get_parser(0, lang)
            if not parser then
                vim.notify("Parser não encontrado para a linguagem: " .. lang, vim.log.levels.WARN)
            end
            return parser
        end

        -- Registra o parser para a linguagem "templ"
        local treesitter_parser_config = ts_parsers.get_parser_configs()
        treesitter_parser_config.templ = {
            install_info = {
                url = "https://github.com/vrischmann/tree-sitter-templ.git",
                files = { "src/parser.c", "src/scanner.c" },
                branch = "master",
            },
        }

        -- Tenta registrar a linguagem "templ" de forma segura
        if safe_get_parser("templ") then
            vim.treesitter.language.register("templ", "templ")
        end
    end,
}

