return {
  "stevearc/dressing.nvim",
  event = "VeryLazy",
}
