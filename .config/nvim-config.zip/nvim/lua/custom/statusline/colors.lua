local function highlight(tag, foreground, background, style)
  vim.cmd("highlight " .. tag .. " guifg=" .. foreground .. " guibg=" .. background .. " gui=" .. style)
end

-- Cores atualizadas
highlight("StatusMode", "#ffffff", "#1E1E2E", "bold")  -- Modo: Branco no fundo escuro
highlight("StatusBranch", "#65D1FF", "NONE", "NONE")  -- Branch: Azul claro
highlight("StatusFile", "#c3ccdc", "NONE", "NONE")    -- Arquivo: Cores mais brilhantes
highlight("StatusSaved", "#adb5bd", "NONE", "NONE")    -- Salvo
highlight("StatusWarnings", "#FFDA7B", "NONE", "NONE") -- Avisos
highlight("StatusErrors", "#FF4A4A", "NONE", "NONE")    -- Erros
highlight("StatusInfos", "#89B4FA", "NONE", "NONE")     -- Informações

highlight("BranchComponentStatus", "#444444", "NONE", "NONE")
