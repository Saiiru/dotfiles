
function get_mode_component()
  local mode = vim.fn.mode()
  return get_mode_group(mode)
end

function get_saved_component()
  local saved = vim.bo.modified and "*" or ""
  return saved
end
