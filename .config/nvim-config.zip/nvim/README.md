### 🌑 init.lua

this repository contains everything related to my neovim configuration, from basic sets and remaps, to a custom status line and theme.
